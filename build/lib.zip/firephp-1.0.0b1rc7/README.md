FirePHP Server Library
======================

Status: beta

Version: [1.0.0b1rc7](https://github.com/firephp/firephp/tree/v1.0.0b1rc7)

This archive contains the *FirePHP* PHP server library.

Links
-----

  * Documentation: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/
  * Install: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/Install
  * Support: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/OpenSource#support
  * Author: [Christoph Dorn](http://www.christophdorn.com/)
  * License: [MIT License](http://www.opensource.org/licenses/mit-license.php)
