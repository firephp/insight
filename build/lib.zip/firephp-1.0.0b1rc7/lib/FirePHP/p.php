<?php

function p($data, $label=null) {
    FirePHP::plugin("firephp")->p($data, $label);
}
