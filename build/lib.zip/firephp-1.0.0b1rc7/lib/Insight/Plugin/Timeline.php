<?php

class Insight_Plugin_Timeline extends Insight_Plugin_API {

/*
    public function renderer($renderer) {
        return $this->message->meta(array(
            'renderer' => $renderer
        ));
    }

    public function set($name, $value) {
        return $this->message->send(array(
            'name' => $name,
            'value' => $value
        ));
    }
*/

}
